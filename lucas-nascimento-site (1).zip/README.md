# Lucas Nascimento | Advocacia Criminal

Este repositório contém o site profissional do advogado Lucas Nascimento.

## 🚀 Deploy rápido

Para publicar este site com 1 clique usando a Vercel:

👉 [Deploy na Vercel](https://vercel.com/new/import?s=https://github.com/lucasnascvinicius/lucas-nascimento-adv)

## 📁 Como usar este projeto

1. Faça upload dos arquivos no seu GitHub no repositório `lucas-nascimento-adv`
2. Acesse o link acima para publicar diretamente via Vercel
